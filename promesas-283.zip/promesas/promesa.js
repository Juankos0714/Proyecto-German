const miPromesa = new Promise((resolve, reject) => {
        const exito = true;
        if (exito) {
            //el argumento del resolve es el valor
            //de resolución de la promesa. El valor de resolucion
            // puede ser string, entero etc
            //Si una promes se resuleve, no se rechaza
            resolve("¡Operación completada con éxito!");
        } else {
            //si una pormesa se rechaza, no se resuelve
            //El argumento del reject es la información del error
            reject("Hubo un error en la operación.");
        }
    });

// Usando la promesa
//el then solo se ejecuta si la promesa es resuelta
//ESTA OPERACIÓN ES ASINCRONA
miPromesa.then((mensaje) => {
        console.log(mensaje); //"¡Operación completada con éxito!"
    })
    .catch((error) => {
        console.error(error); 
    });